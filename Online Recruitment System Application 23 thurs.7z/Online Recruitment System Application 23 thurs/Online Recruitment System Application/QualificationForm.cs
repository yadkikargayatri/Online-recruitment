﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Online_Recruitment_System_Application
{
    public partial class QualificationForm : Form
    {
        public QualificationForm()
        {
            InitializeComponent();
        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();

            SkillsForm frm4 = new SkillsForm();
            frm4.Visible = true;

        }

        private void button1_Click(object sender, EventArgs e)
        {
            PersonalDetailsForm frm3 = new PersonalDetailsForm();
            frm3.Visible = true;
            this.Hide();

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            //ComboBox comboBox1 = new ComboBox();
            comboBox1.Items.Add("Bachelor of Engineering");

        }

        private void folderBrowserDialog1_HelpRequest(object sender, EventArgs e)
        {

        }
    }
}

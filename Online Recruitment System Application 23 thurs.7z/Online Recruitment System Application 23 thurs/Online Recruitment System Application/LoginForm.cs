﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Online_Recruitment_System_Application
{
    public partial class LoginForm : Form
    {
        public LoginForm()
        {
            InitializeComponent();
        }

        private void LoginForm_Load(object sender, EventArgs e)
        {
            groupBox1.Hide();
            groupBox2.Hide();
            
        }

        protected void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            LoginForm frm1=new LoginForm();

            PersonalDetailsForm frm2 = new PersonalDetailsForm();
            this.Hide();
            frm2.Show();           
            
        }

        protected void button1_Click(object sender, EventArgs e)
        {
            LoginForm frm1 = new LoginForm();
            Jobseeker_sProfile frm = new Jobseeker_sProfile();
            frm.Visible = true;
            frm1.Hide();

        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {
           // groupBox1.Hide();
        }

        private void groupBox3_Enter(object sender, EventArgs e)
        {
           
        }

        private void groupBox2_Enter(object sender, EventArgs e)
        {

        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            groupBox1.Visible = true; 
            groupBox2.Hide();
        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            groupBox2.Visible = true;
            groupBox1.Hide();
        }
    }
}
